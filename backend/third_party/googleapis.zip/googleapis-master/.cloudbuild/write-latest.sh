#!/bin/bash

echo $1 > cloud_build_latest
